package com.team.ghana.enums;

public enum EmploySearchCriteria {
    BUSINESSUNIT, DEPARTMENT, UNIT
}
