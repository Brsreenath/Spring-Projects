# Employee-management-System #
Employee management system using spring boot and mySql

Requirements:

1. Spring Tool Suite IDE.
2. JDK 8.
3. Maven 2.5.
4. MYSQL Database.

Changes need to be done in code to run it.

1. In "application.properties" file write database username and password.
2. In AppServicesImplementation file change the path in the saveImage function to the path of the images folder of your system present in src->static->images.
3. 
4. To run the project run StarterApplication file as Java Application.
5. To run Selenium Testing - 
6. To run Junit Test Cases-

