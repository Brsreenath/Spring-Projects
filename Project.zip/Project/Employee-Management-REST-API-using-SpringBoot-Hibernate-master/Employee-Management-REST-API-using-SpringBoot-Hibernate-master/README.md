# Employee-Management-REST-API-using-SpringBoot-Hibernate
In this project, we have designed REST APIs for all CRUD operations that can be used for Employee Management, using Spring Boot features and saving the data in MySQL using Hibernate.

A new maven project can be pre-designed using Spring Boot. www.start.spring.io
