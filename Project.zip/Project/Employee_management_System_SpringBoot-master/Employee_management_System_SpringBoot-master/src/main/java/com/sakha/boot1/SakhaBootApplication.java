package com.sakha.boot1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SakhaBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SakhaBootApplication.class, args);
	}

}
